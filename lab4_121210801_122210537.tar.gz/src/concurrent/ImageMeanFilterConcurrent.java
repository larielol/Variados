import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class ImageMeanFilterConcurrent {
    
    private static AtomicInteger changedPixels = new AtomicInteger(0);
    private static AtomicInteger unchangedPixels = new AtomicInteger(0);
    
    public static void main(String[] args) throws IOException, InterruptedException {
        if (args.length < 2) {
            System.err.println("Uso: java ImageMeanFilterConcurrent <imagem> <threads>");
            System.err.println("Exemplo: java ImageMeanFilterConcurrent ../../data/small_sample.jpg 4");
            System.exit(1);
        }

        String inputPath = args[0];
        int numThreads = Integer.parseInt(args[1]);
        
        if (numThreads < 2) {
            System.err.println("Número de threads deve ser no mínimo 2");
            System.exit(1);
        }

        BufferedImage originalImage = ImageIO.read(new File(inputPath));
        int width = originalImage.getWidth();
        int height = originalImage.getHeight();
        
        BufferedImage filteredImage = new BufferedImage(
            width, height, BufferedImage.TYPE_INT_RGB
        );

        changedPixels.set(0);
        unchangedPixels.set(0);

        int rowsPerThread = height / numThreads;
        int remainingRows = height % numThreads;
        
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
        int startRow = 0;
        
        for (int i = 0; i < numThreads; i++) {
            int rows = rowsPerThread + (i < remainingRows ? 1 : 0);
            if (rows == 0) continue;
            int endRow = startRow + rows;
            executor.submit(new FilterTask(
                originalImage, filteredImage, startRow, endRow, width
            ));
            startRow = endRow;
        }

        executor.shutdown();
        executor.awaitTermination(1, TimeUnit.HOURS);

        String outputPath = "filtered_concurrent.jpg";
        ImageIO.write(filteredImage, "jpg", new File(outputPath));

    }

    static class FilterTask implements Runnable {
        private final BufferedImage original;
        private final BufferedImage filtered;
        private final int startY;
        private final int endY;
        private final int width;
        private final int kernelSize = 7;
        private final int pad;

        public FilterTask(BufferedImage original, BufferedImage filtered, 
                         int startY, int endY, int width) {
            this.original = original;
            this.filtered = filtered;
            this.startY = startY;
            this.endY = endY;
            this.width = width;
            this.pad = kernelSize / 2;
        }

        @Override
        public void run() {
            for (int y = startY; y < endY; y++) {
                for (int x = 0; x < width; x++) {
                    int[] avgColor = calculateNeighborhoodAverage(x, y);
                    int filteredRGB = (avgColor[0] << 16) | (avgColor[1] << 8) | avgColor[2];
                    
                    int originalRGB = original.getRGB(x, y);
                    
                    filtered.setRGB(x, y, filteredRGB);
                    
                    if (originalRGB == filteredRGB) {
                        unchangedPixels.incrementAndGet();
                    } else {
                        changedPixels.incrementAndGet();
                    }
                }
            }
        }

        private int[] calculateNeighborhoodAverage(int centerX, int centerY) {
            long redSum = 0, greenSum = 0, blueSum = 0;
            int pixelCount = 0;

            for (int dy = -pad; dy <= pad; dy++) {
                for (int dx = -pad; dx <= pad; dx++) {
                    int x = centerX + dx;
                    int y = centerY + dy;
                    if (x >= 0 && x < width && y >= 0 && y < original.getHeight()) {
                        int rgb = original.getRGB(x, y);
                        redSum += (rgb >> 16) & 0xFF;
                        greenSum += (rgb >> 8) & 0xFF;
                        blueSum += rgb & 0xFF;
                        pixelCount++;
                    }
                }
            }

            return new int[] {
                (int)(redSum / pixelCount),
                (int)(greenSum / pixelCount),
                (int)(blueSum / pixelCount)
            };
        }
    }
}